package it.epicode.be.epicenergyservices;

import java.time.LocalDate;
import java.util.List;

import javax.annotation.Resource;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import it.epicode.be.epicenergyservices.controllers.AuthController;
import it.epicode.be.epicenergyservices.controllers.CustomerController;
import it.epicode.be.epicenergyservices.models.Address;
import it.epicode.be.epicenergyservices.models.Customer;
import it.epicode.be.epicenergyservices.models.Municipality;
import it.epicode.be.epicenergyservices.models.Province;
import it.epicode.be.epicenergyservices.payloads.LoginRequest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


@SpringBootTest
@RunWith(SpringRunner.class)
@WebAppConfiguration
@AutoConfiguration
class EpicEnergyServicesApplicationTests {
	
	@Resource
	CustomerController cc;
	@Resource
	AuthController ac;
	@Resource
	PasswordEncoder pe;
	
	Province p1;
	Municipality m1;
	Address a1;
	Address a2;
	Customer c1;
	
	
	@BeforeEach
	public void getEntities() {
		p1 = Province.builder().acronym("RC")
				.name("Reggio Calabria")
				.region("Calabria")
				.build();
		m1 = Municipality.builder()
				.districtCode(63)
				.province(p1)
				.name("Reggio di Calabria")
				.build();
		a1 = Address.builder()
				.postCode(89122)
				.number(4).city("Reggio Calabria").street("via Vito Superiore")
				.municipality(m1)
				.build();
		a2 = Address.builder()
				.postCode(89100)
				.number(6).city("Reggio Calabria").street("via Dei Pazzi")
				.municipality(m1)
				.build();
		c1 = Customer.builder().contactSurname("Palumbo")
				.subDate(LocalDate.parse("2020-12-19"))
				.lastDate(LocalDate.parse("2021-03-31"))
				.email("alighiero.leone@hotmail.com")
				.contactEmail("silvano.santoro@yahoo.com")
				.legalAddress(a1)
				.productionAddress(a1)
				.build();
	}
	
	@Test
	@DisplayName("DataCheckUp")
	void testData() {
		assertEquals(c1.getLegalAddress(), c1.getProductionAddress());
		c1.setProductionAddress(a2);
		assertTrue(c1.getLegalAddress()!= c1.getProductionAddress());
	}
	
	@Test
	@DisplayName("HttpCallCheckUp")
	void testGetHttpCall () {
		cc.getById(1).getBody().toString().contains("silvano");
	}
	
	@Test
	@DisplayName("CheckLogin")
	void testLogin () {
		LoginRequest lr = new LoginRequest();
		lr.setUsername("pippobaudo");
		lr.setPassword("pippoinzaghi");
		ac.authenticateUser(lr).getBody().toString().contains("token");
	}
	
	@Test
	@DisplayName("CheckRoute")
	void testRoute() {
		List<Customer> list = cc.getAll().getBody();
		assertTrue(list.size() == 3);
		assertEquals(list.get(0).getBusinessName(), "Bruno, Ferretti e Leone s.r.l.");
	}
}
