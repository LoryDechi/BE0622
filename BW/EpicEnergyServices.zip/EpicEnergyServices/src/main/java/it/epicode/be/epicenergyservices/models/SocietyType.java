package it.epicode.be.epicenergyservices.models;

public enum SocietyType {
	PA, SAS, SRL, SPA

}
