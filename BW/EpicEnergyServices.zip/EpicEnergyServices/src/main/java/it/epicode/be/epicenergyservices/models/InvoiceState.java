package it.epicode.be.epicenergyservices.models;

public enum InvoiceState {
PENDING, EMITTED, EXPIRED, PAID
}
