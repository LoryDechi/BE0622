package it.epicode.be.epicenergyservices.models;

public enum RoleType {
	User,
	Administrator
}
